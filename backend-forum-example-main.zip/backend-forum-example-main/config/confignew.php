<?php

return [
    'frontend_verify_email_url' => env('FRONTEND_VERIFY_EMAIL_URL')
];
